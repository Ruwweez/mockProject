#main_menu.py
import tkinter as tk
from tkinter import ttk
import sqlite3

def open_main_menu(username, userType, root, conn):
    root.title(f"{userType.capitalize()} Menu")
    root.geometry("1200x900")
    
    tab_control = ttk.Notebook(root)

    courses_tab = ttk.Frame(tab_control)
    tab_control.add(courses_tab, text='Courses')

    def on_course_click(course_id):
        course_window = tk.Toplevel(root)
        course_window.title("Course Details")
        course_window.geometry("1200x900")
        
        course_frame = ttk.Frame(course_window)
        course_frame.pack(padx=10, pady=10)

        course_label = ttk.Label(course_frame, text=f"Course ID: {course_id}")
        course_label.pack(pady=5)

        tab_control_course = ttk.Notebook(course_frame)

        learning_materials_tab = ttk.Frame(tab_control_course)
        tab_control_course.add(learning_materials_tab, text='Learning Materials')
        if not learning_materials_available(course_id):
            ttk.Label(learning_materials_tab, text="Learning Materials for Course ID are empty").pack(pady=10)

        assessments_tab = ttk.Frame(tab_control_course)
        tab_control_course.add(assessments_tab, text='Assessments')
        if not assessments_available(course_id):
            ttk.Label(assessments_tab, text="Assessments for Course ID are empty").pack(pady=10)

        tab_control_course.pack(expand=1, fill='both')

    def learning_materials_available(course_id):
        # Check if learning materials are available for the course
        return False  # Replace this with your logic to check if learning materials are available

    def assessments_available(course_id):
        # Check if assessments are available for the course
        return False  # Replace this with your logic to check if assessments are available

    try:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Courses")
        courses = cursor.fetchall()

        for idx, course in enumerate(courses):
            course_frame = ttk.Frame(courses_tab, borderwidth=2, relief="solid")
            course_frame.grid(row=idx // 2, column=idx % 2, padx=10, pady=10, sticky='nsew')

            course_id = course[0]
            course_name = course[1]
            course_code = course[2]

            course_label = ttk.Label(course_frame, text=f"Course Name: {course_name}\nCourse Code: {course_code}", cursor="hand2", anchor="center")
            course_label.pack(expand=True, fill='both')

            course_label.bind("<Button-1>", lambda event, cid=course_id: on_course_click(cid))

            # Configure row and column weights to make the frames expand
            courses_tab.grid_rowconfigure(idx // 2, weight=1)
            courses_tab.grid_columnconfigure(idx % 2, weight=1)

    except sqlite3.Error as e:
        print(f"Error retrieving courses: {e}")

    tab_control.pack(expand=1, fill='both')

    grades_tab = ttk.Frame(tab_control)
    tab_control.add(grades_tab, text='Grades')
    for idx, course in enumerate(courses):
        course_frame = ttk.Frame(grades_tab, borderwidth=2, relief="solid")
        course_frame.grid(row=idx // 2, column=idx % 2, padx=10, pady=10, sticky='nsew')

        course_id = course[0]
        ttk.Label(course_frame, text=f"No grades available for Course ID: {course_id}", anchor="center").pack(expand=True, fill='both')

        # Configure row and column weights to make the frames expand
        grades_tab.grid_rowconfigure(idx // 2, weight=1)
        grades_tab.grid_columnconfigure(idx % 2, weight=1)

    account_settings_tab = ttk.Frame(tab_control)
    tab_control.add(account_settings_tab, text='Account Settings')

    # Circular frame with letter PE
    circular_frame = tk.Frame(account_settings_tab, width=50, height=50, bg="white", relief="sunken")
    circular_frame.pack(pady=10)
    pe_label = tk.Label(circular_frame, text="PE", font=("Helvetica", 24), bg="white")
    pe_label.pack(expand=True)

    # Display username and usertype
    ttk.Label(account_settings_tab, text=f"Username: {username}").pack()
    ttk.Label(account_settings_tab, text=f"User Type: {userType.capitalize()}").pack()

    # Add clickable options
    ttk.Label(account_settings_tab, text="Gender:").pack()
    gender_option = tk.StringVar(value="Select Gender")
    gender_combobox = ttk.Combobox(account_settings_tab, textvariable=gender_option, values=["Select Gender", "He/Him", "She/Her", "They/Them"])
    gender_combobox.pack(pady=5)

    ttk.Label(account_settings_tab, text="Add Email:").pack()
    email_entry = ttk.Entry(account_settings_tab)
    email_entry.insert(0, "Email Address")
    email_entry.pack(pady=5)

    tab_control.pack(expand=1, fill='both')
