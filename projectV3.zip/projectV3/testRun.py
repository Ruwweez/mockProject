import tkinter as tk
from tkinter import messagebox, ttk
import sqlite3
import main_menu

conn = sqlite3.connect('userAccounts.db')


def destroy_gui():
    root.destroy()


def login(username_entry, password_entry):
    username = username_entry.get()
    password = password_entry.get()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Users WHERE UserName=? AND Password=?", (username, password))
    user = cursor.fetchone()
    user_type = None  # Initialize user_type
    if user:
        if user[2] == 'Student':
            messagebox.showinfo("Login Successful", "Welcome Student!")
            user_type = 'Student'
        elif user[2] == 'Faculty':
            messagebox.showinfo("Login Successful", "Welcome Faculty!")
            user_type = 'Faculty'
        after_login(username, user_type)  # Execute the after login function
    else:
        messagebox.showerror("Login Failed", "Invalid username or password")


def after_login(username, user_type):
    root = tk.Tk()
    root.title("Main Menu")
    user_type = user_type.capitalize() if user_type else ""  # Capitalize user_type if it's not None
    main_menu.open_main_menu(username, user_type, root, conn)

def create_gui():
    global root
    root = tk.Tk()
    root.title("ParrotEdge")  # Set the window title to "ParrotEdge"
    root.geometry("1200x900")  # Set a standard frame resolution

    # Load and resize the image to 50x50 pixels
    image = tk.PhotoImage(file="parrotEdge.png")
    resized_image = image.subsample(10)  # Subsample by a factor of 10 to get 50x50 pixels
    image_label = tk.Label(root, image=resized_image)
    image_label.pack()

    # Display the welcome message
    header_label = tk.Label(root, text="Welcome to ParrotEdge", font=("Helvetica", 24))
    header_label.pack(pady=10)

    tab_control = ttk.Notebook(root)

    login_tab = ttk.Frame(tab_control)
    tab_control.add(login_tab, text='Login')

    ttk.Label(login_tab, text="Username:", font=("Helvetica", 11)).pack(pady=5)
    username_entry = ttk.Entry(login_tab)
    username_entry.pack(pady=5)

    ttk.Label(login_tab, text="Password:", font=("Helvetica", 11)).pack(pady=5)
    password_entry = ttk.Entry(login_tab, show="*")
    password_entry.pack(pady=5)

    login_button = ttk.Button(login_tab, text="Login", command=lambda: login(username_entry, password_entry))
    login_button.pack(pady=10)

    tab_control.pack(expand=1, fill='both')
    root.mainloop()

if __name__ == "__main__":
    create_gui()
